#!/usr/bin/env python

import sys
import os
import glob
from setuptools import find_packages, setup
from shutil import copyfile, copytree, rmtree

DIST_TMP = "share"
bigdl_home = os.path.abspath(__file__ + "/../../../")


def is_release():
    code_path = bigdl_home + "/pyspark/dl/util/common.py"
    print("Checking: %s" % code_path)
    if os.path.exists(code_path):
        return False
    return True


def init_env():
    if not is_release():
        print("Start to build distributed package")
        print("HOME OF BIG DL: " + bigdl_home)
        dist_source = bigdl_home + "/dist"
        if not os.path.exists(dist_source):
            raise Exception("%s doesn't exist.Please make-dist.sh first" % dist_source)
        if os.path.exists(DIST_TMP):
            rmtree(DIST_TMP)
        copytree(dist_source, DIST_TMP)
        copyfile(bigdl_home + "/pyspark/dl/util/__init__.py", DIST_TMP + "/__init__.py")
    else:
        print("Do nothing for release installation")


def setup_package():
    metadata = dict(
        name='Bigbig',
        version='0.1.4',
        description='Bigbig on PySpark',
        author='Zhichao,Li',
        author_email='zhichao.li@gmail.com',
        license='Apache License, Version 2.0',
        packages=['nn', 'util', 'optim', 'dataset', 'models', 'share'],
        install_requires=['numpy>=0.9'], 
        include_package_data=True,
        package_data={"share": ['lib/*.jar', 'conf/*.conf', 'bin']},
        url = 'https://github.com/intel-analytics/Bigbig',
        download_url = 'https://github.com/intel-analytics/Bigbig/archive/v0.1.0.tar.gz'
    )

    setup(**metadata)


if __name__ == '__main__':
    try:
        init_env()
        setup_package()
    except Exception as e:
        raise e
    finally:
        pass
        if os.path.exists(DIST_TMP):
            rmtree(DIST_TMP)

